<?php

use Illuminate\Support\Facades\Route;

/*Route::get('/', function () {
    return view('welcome');
});*/

//Tampilan Dapur
/*Route::get('/dapur/daftarpesanan-all', function () {
    return view('dapur.daftarpesanan-all');
});

Route::get('/dapur/daftarpesanan-baru', function () {
    return view('dapur.daftarpesanan-baru');
});

Route::get('/dapur/daftarpesanan-proses', function () {
    return view('dapur.daftarpesanan-proses');
});

Route::get('/dapur/daftarpesanan-selesai', function () {
    return view('dapur.daftarpesanan-selesai');
});

Route::get('/dapur/stockmenu-all', function () {
    return view('dapur.stockmenu-all');
});

Route::get('/dapur/stockmenu-pilihmenu', function () {
    return view('dapur.stockmenu-pilihmenu');
});

Route::get('/dapur/stockmenu-tambahstock', function () {
    return view('dapur.stockmenu-tambahstock');
});

//Tampilan Kasir
Route::get('/kasir/menu-kategori', function () {
    return view('kasir.menu-kategori');
});

*/



//Tampilan Pelanggan
Route::get('/', function () {
    return view('pelanggan.input-nomeja');
});

Route::get('/pelanggan/home', function () {
    return view('pelanggan.home');
});

Route::get('/pelanggan/menu-makanan', function () {
    return view('pelanggan.menu-makanan');
});

Route::get('/pelanggan/menu-minuman', function () {
    return view('pelanggan.menu-minuman');
});

Route::get('/pelanggan/menu-snack', function () {
    return view('pelanggan.menu-snack');
});

Route::get('/pelanggan/menu-detail', function () {
    return view('pelanggan.menu-detail');
});

Route::get('/pelanggan/menu-keranjang', function () {
    return view('pelanggan.menu-keranjang');
});

Route::get('/pelanggan/menu-pembayaranqris', function () {
    return view('pelanggan.menu-pembayaranqris');
});

Route::get('/pelanggan/menu-pembayarantunai', function () {
    return view('pelanggan.menu-pembayarantunai');
});

Route::get('/pelanggan/pesanan-livetracking', function () {
    return view('pelanggan.pesanan-livetracking');
});

Route::get('/pelanggan/splitbill-scan', function () {
    return view('pelanggan.splitbill-scan');
});

Route::get('/pelanggan/splitbill-konfirmasiitem', function () {
    return view('pelanggan.splitbill-konfirmasiitem');
});

Route::get('/pelanggan/splitbill-bagibill', function () {
    return view('pelanggan.splitbill-bagibill');
});

Route::get('/pelanggan/splitbill-jumlahtotal', function () {
    return view('pelanggan.splitbill-jumlahtotal');
});

Route::get('/pelanggan/pesanan-riwayatpesanan', function () {
    return view('pelanggan.pesanan-riwayatpesanan');
});



