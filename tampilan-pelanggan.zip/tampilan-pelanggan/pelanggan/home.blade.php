<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pelanggan (Home)</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Poppins', sans-serif;
        }

        .hero {
            background: linear-gradient(to bottom, #FADA7A 60%, #FFFFFF 100%);
        }


        @media screen and (max-width: 768px) {
        .hero {
            background: linear-gradient(to bottom, #FADA7A  60%, #FFFFFF 100%);
        }

        }

    </style>
</head>
<body class="bg-[#FFFFFF] relative">

   <!-- Overlay Blur -->
   <div id="overlay" class="fixed inset-0 z-40 hidden backdrop-blur-md bg-black/40" onclick="toggleSidebar()"></div>

   @extends('layout.master-pelanggan')

   @section('content')


    <div class="relative content">

        <!--Hero-->
        <div class="flex flex-row items-center justify-between gap-5 py-4 hero md:px-0 md:py-4">
            <!-- Teks -->
            <p class="hero-text text-center font-medium text-[16px] md:text-[20px] w-[50%] md:w-[50%] transform translate-x-[20px] md:translate-x-[120px]">
                Tinggal Klik dan Nikmati Hidangan Enak!
            </p>

            <!-- Gambar Orang -->
            <div class="flex items-center hero-gambar">
                <img src="/images/orang-home.png" alt="gambar"
                    class="w-32 h-32 md:w-60 md:h-60 object-cover -translate-x-[20px] transform md:-translate-x-[200px]">
            </div>

        </div>


        <div class="p-4 pt-2 md:p-6 ">
        <div class="flex flex-col w-full space-y-3">
            <!-- No Meja -->
            <div class="meja-pelanggan flex justify-between items-center p-2 rounded-3xl w-full bg-[#FADA7A]">
                <!-- Icon Meja dan Teks -->
                <div class="flex items-center pl-4 md:pl-4">
                    <img src="/images/meja-pelanggan.png" alt="gambar" class="w-[30px] h-[20px] md:w-[35px] md:h-[25px] ">
                    <span class="text-[16px] font-normal md:text-[18px] pl-4 md:pl-4">Meja saat ini</span>
                </div>
                <!-- Nomor Meja -->
                <span class="text-[16px] md:text-[18px] font-normal mr-4 md:mr-10">04</span>
            </div>

            <!-- Search -->
            <div class="search-pelanggan flex items-center bg-[#E5E1DA] p-1 rounded-3xl shadow-sm w-full">
                <input type="text" placeholder="Anda ingin makan apa hari ini?"
                    class="flex-1 bg-transparent outline-none pl-4 md:pl-6 placeholder-black text-[12px] md:text-base font-thin">
                <!--Button Search-->
                <button class="icon-search w-10 h-10 flex items-center justify-center rounded-full bg-[#EFB036] hover:bg-[#FFF6DA] mr-2 md:mr-6">
                    <!-- Icons Search -->
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-[20px] h-[20px]">
                        <path stroke-linecap="round" stroke-linejoin="round" d="m21 21-5.197-5.197m0 0A7.5 7.5 0 1 0 5.196 5.196a7.5 7.5 0 0 0 10.607 10.607Z" />
                    </svg>
                </button>
            </div>
        </div>

        <!-- Banner (Gambar Iklan) -->
        <div class="mt-4">
            <img src="/images/banner.jpeg" alt="Banner" class="w-full rounded-md">
        </div>

        <!-- Menu Kategori -->
        <h2 class="mt-4 text-[16px] md:text-[18px] font-medium">Menu</h2>
        <div class="grid grid-cols-2 gap-2 mt-2 md:flex md:flex-wrap md:space-x-4 md:gap-4">
            <a href="/pelanggan/menu-makanan" class="menu-makanan bg-[#FFFFFF] px-4 py-2 min-w-[120px] border-2  w-full md:w-auto rounded-3xl shadow-md items-center flex space-x-2 group hover:bg-[#FADA7A] transition">
                <span>
                    <img src="/images/makanan-pelanggan.png" alt="Makanan"
                        class="icon-menu-kategori w-[25px] h-[25px] object-contain rounded-full justify-start transition">
                </span>
                <span class="text-[14px] font-medium md:text-[16px] justify-start">Makanan</span>
                </a>
            <a href="/pelanggan/menu-minuman" class="menu-makanan bg-[#FFFFFF] px-4 py-2 min-w-[120px] border-2  w-full md:w-auto rounded-3xl shadow-md items-center flex space-x-2 group hover:bg-[#FADA7A] transition">
                <span>
                    <img src="/images/minuman-pelanggan.png" alt="Minuman"
                         class="icon-menu-kategori w-[25px] h-[25px] object-contain rounded-full justify-start transition">
                </span>
                <span class="text-[14px] font-medium md:text-[16px] justify-start">Minuman</span>
            </a>
            <a href="/pelanggan/menu-snack" class="menu-makanan bg-[#FFFFFF] px-4 py-2 min-w-[120px] border-2 w-full md:w-auto rounded-3xl shadow-md items-center flex space-x-2 group hover:bg-[#FADA7A] transition">
                <span>
                    <img src="/images/snack-pelanggan.png" alt="Snack"
                         class="icon-menu-kategori w-[25px] h-[25px] object-contain rounded-full justify-start transition">
                </span>
                <span class="text-[14px] font-medium md:text-[16px] justify-start">Snack</span>
            </a>
        </div>

        <!-- Rekomendasi -->
        <h2 class="mt-6 text-[16px] md:text-[18px] font-medium">Rekomendasi</h2>
        <div class="grid grid-cols-1 gap-4 mt-2 md:grid-cols-2">

            <!-- Rekomendasi 1 -->
            <div class="bg-[#FFFFFF] rounded-2xl shadow-md flex items-center border border-1 overflow-hidden h-[100px] md:h-[110px] ">
                <!-- Gambar -->
                <div class="flex-shrink-0 h-full">
                    <img src="/images/bakso campur.jpg" alt="Bakso Campur" class="w-[100px] md:w-[110px] h-full rounded-2xl object-cover">
                </div>

                <!-- Konten -->
                <div class="flex flex-col flex-1 h-full p-3 md:p-2">
                    <h2 class="text-[14px] md:text-[18px] font-medium">Bakso Campur</h2>
                    <p class="text-[12px] md:text-[16px] text-[#686D76] font-light leading-tight">Isi: Pentol, tahu, gorengan</p>

                    <!-- Bagian Harga dan Button -->
                    <div class="flex items-center justify-between mt-auto">
                        <p class="text-black font-semibold text-[16px] md:text-[20px] mt-1">Rp 15.000</p>
                        <div id="orderButtonContainer1">
                            <a href="/pelanggan/menu-detail" onclick="saveItemId(1)"  class="w-[75px] h-[25px] md:w-[100px] md:h-[33px] rounded-full text-[12px] md:text-[16px] text-black bg-[#B8D576] hover:bg-[#FFF6DA] active:bg-[#FFF6DA] font-medium flex items-center justify-center">
                               Tambah
                            </a>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Rekomendasi 2 -->
            <div class="bg-[#FFFFFF] rounded-2xl shadow-md flex items-center border border-1 overflow-hidden h-[100px] md:h-[110px]">
                <!-- Gambar -->
                <div class="flex-shrink-0 h-full">
                    <img src="/images/mie ayam.jpg" alt="Bakso Campur" class="w-[100px] md:w-[110px] h-full rounded-2xl object-cover">
                </div>

                <!-- Konten -->
                <div class="flex flex-col flex-1 h-full p-3 md:p-2">
                    <h2 class="text-[14px] md:text-[18px] font-medium">Mie Ayam</h2>
                    <p class="text-[12px] md:text-[16px] text-[#686D76] font-light leading-tight">Mie dengan topping potongan ayam berbumbu kecap</p>

                    <!-- Bagian Harga dan Button -->
                    <div class="flex items-center justify-between mt-auto">
                        <p class="text-black font-semibold text-[16px] md:text-[20px] mt-1">Rp 15.000</p>
                        <div id="orderButtonContainer2">
                            <a href="/pelanggan/menu-detail" onclick="saveItemId(2)"  class="w-[75px] h-[25px] md:w-[100px] md:h-[33px] rounded-full text-[12px] md:text-[16px] text-black bg-[#B8D576] hover:bg-[#FFF6DA] active:bg-[#FFF6DA] font-medium flex items-center justify-center">
                               Tambah
                            </a>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Rekomendasi 3 -->
            <div class="bg-[#FFFFFF] rounded-2xl shadow-md flex items-center border border-1 overflow-hidden h-[100px] md:h-[110px] ">
                <!-- Gambar -->
                <div class="flex-shrink-0 h-full">
                    <img src="/images/es teh.jpg" alt="Bakso Campur" class="w-[100px] md:w-[110px] h-full rounded-2xl object-cover">
                </div>

                <!-- Konten -->
                <div class="flex flex-col flex-1 h-full p-3 md:p-2">
                    <h2 class="text-[14px] md:text-[18px] font-medium">Es Teh</h2>
                    <p class="text-[12px] md:text-[16px] text-[#686D76] font-light leading-tight"></p>

                    <!-- Bagian Harga dan Button -->
                    <div class="flex items-center justify-between mt-auto">
                        <p class="text-black font-semibold text-[16px] md:text-[20px] mt-1">Rp 3.000</p>
                        <div id="orderButtonContainer3">
                            <a href="/pelanggan/menu-detail" onclick="saveItemId(3)"  class="w-[75px] h-[25px] md:w-[100px] md:h-[33px] rounded-full text-[12px] md:text-[16px] text-black bg-[#B8D576] hover:bg-[#FFF6DA] active:bg-[#FFF6DA] font-medium flex items-center justify-center">
                               Tambah
                            </a>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Rekomendasi 4 -->
            <div class="bg-[#FFFFFF] rounded-2xl shadow-md flex items-center border border-1 overflow-hidden h-[100px] md:h-[110px] ">
                <!-- Gambar -->
                <div class="flex-shrink-0 h-full">
                    <img src="/images/keripik pisang.jpg" alt="Bakso Campur" class="w-[100px] md:w-[110px] h-full rounded-2xl object-cover">
                </div>

                <!-- Konten -->
                <div class="flex flex-col flex-1 h-full p-3 md:p-2">
                    <h2 class="text-[14px] md:text-[18px] font-medium">Keripik Pisang</h2>
                    <p class="text-[12px] md:text-[16px] text-[#686D76] font-light leading-tight">Irisan pisang pilihan yang digoreng hingga renyah</p>

                    <!-- Bagian Harga dan Button -->
                    <div class="flex items-center justify-between mt-auto">
                        <p class="text-black font-semibold text-[16px] md:text-[20px] mt-1">Rp 7.000</p>
                        <div id="orderButtonContainer4">
                            <a href="/pelanggan/menu-detail" onclick="saveItemId(4)"  class="w-[75px] h-[25px] md:w-[100px] md:h-[33px] rounded-full text-[12px] md:text-[16px] text-black bg-[#B8D576] hover:bg-[#FFF6DA] active:bg-[#FFF6DA] font-medium flex items-center justify-center">
                               Tambah
                            </a>
                        </div>
                    </div>
                </div>
            </div>

        </div>
        </div>


    </div>

    @endsection


    <script>

        // Mengubah ketika user membuat sebuah pesanan
        function saveItemId(itemId) {
            sessionStorage.setItem('currentItem', itemId);
        }

        function updateOrderButtons() {
            for (let i = 1; i <= 1000; i++) { // Loop untuk 1000 menu
                let count = localStorage.getItem('orderedItem' + i);
                let container = document.getElementById('orderButtonContainer' + i);

                if (count && container) {
                    container.innerHTML = `
                    <div class="flex items-center bg-[#B8D576] w-[75px] h-[25px] md:w-[100px] md:h-[33px] gap-2 rounded-full border border-1">
                        <div class="flex items-center gap-0 ml-3 md:ml-3 md:gap-[2px]">
                            <button class="text-[20px]" onclick="decreaseCount(${i})">-</button>
                            <span id="count${i}" class="mx-1 text-[12px] md:text-[14px] font-medium md:mx-3 min-w-[24px] text-center">${count}</span>
                            <button class="text-[20px]" onclick="increaseCount(${i})">+</button>
                        </div>
                    </div>
                    `;
                }
            }
        }

        function increaseCount(itemId) {
            let count = parseInt(localStorage.getItem('orderedItem' + itemId) || 1);
            localStorage.setItem('orderedItem' + itemId, count + 1);
            document.getElementById('count' + itemId).innerText = count + 1;
        }

        function decreaseCount(itemId) {
            let count = parseInt(localStorage.getItem('orderedItem' + itemId) || 1);
            if (count > 1) {
                localStorage.setItem('orderedItem' + itemId, count - 1);
                document.getElementById('count' + itemId).innerText = count - 1;
            } else {
                localStorage.removeItem('orderedItem' + itemId);
                location.reload(); // Reload halaman untuk mengembalikan tombol "Tambah"
            }
        }

        // Perbarui tampilan tombol saat halaman dimuat
        document.addEventListener('DOMContentLoaded', updateOrderButtons);
        </script>

</body>
</html>
