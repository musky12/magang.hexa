<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pelanggan (Live Tracking)</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/heroicons@2.0.16/24/solid/index.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Poppins', sans-serif;
        }
    </style>
</head>
<body class="bg-[#FFFFFF] relative">
   <!-- Overlay Blur -->
   <div id="overlay" class="fixed inset-0 z-40 hidden backdrop-blur-md bg-black/40" onclick="toggleSidebar()"></div>

   @extends('layout.master-pelanggan2')

   @section('content')

    <!-- Container -->
    <div class="relative p-4 pb-0 content">

        <div class="flex items-center justify-center pt-2 pb-4 text-black">
            <h1 class="text-[16px] md:text-[18px] font-medium">Riwayat Pesanan</h1>
        </div>

        <div class="pt-2 pb-2">
            <hr class="border-black border-1">
        </div>

        <!--  Dine-In dan No Meja -->
        <div class="flex items-center justify-between p-4 pt-0">
            <!-- Dine-In -->
            <div class="flex flex-col items-start gap-2">
                <div class="flex items-center gap-2">
                    <img src="/images/location-pelanggan-hitam.png" alt="gambar" class="w-6 h-6">
                    <span class="text-[14px] md:text-[18px] font-medium">Dine-In</span>
                </div>
                <span class="text-[12px] md:text-[16px] font-normal pl-7">02 Februari 2025 08:47</span>
            </div>


            <!-- No Pesanan -->
            <div class="flex items-center gap-2 bg-[#FADA7A] px-4 py-1 rounded-full text-sm">
                <span class="text-[14px] md:text-[16px] font-normal">02022501</span>
            </div>


        </div>

        <!--No Meja-->
        <div class="flex items-center justify-center space-x-2 text-black">
            <img src="/images/meja-pelanggan.png" alt="gambar" class="w-[25px] h-[25px] md:w-[30px] md:h-[25px]">
            <span class="text-[14px] md:text-[16px] font-medium">Meja 04</span>
        </div>

        <div class="p-2 pt-2">
            <hr class="border-black border-1">

            <!-- Status Pesanan -->
            <div class="flex items-center justify-center pt-3 pb-3 mr-4 space-x-2 text-black md:space-x-5">
                <!-- Dikonfirmasi -->
                <div class="flex flex-col items-center">
                    <img src="/images/status-dikonfirmasi.png" alt="Bakso Campur" class="w-[25px] h-[25px] md:w-[45px] md:h-[45px] object-cover ">
                    <span class="text-[12px] font-normal mt-2">Dikonfirmasi</span>
                </div>

                <!-- Garis Putus-Putus -->
                <div class="w-[49px] h-4 border-dashed border-t-[2px] border-black"></div>

                <!-- Diproses -->
                <div class="flex flex-col items-center">
                    <img src="/images/status-diproses.png" alt="Bakso Campur" class="w-[45px] h-[45px] md:w-[75px] md:h-[75px] object-cover ">
                    <span class="text-[16px] font-medium mt-2">Diproses</span>
                </div>

                <!-- Garis Putus-Putus -->
                <div class="w-[49px] h-4 border-dashed border-t-[2px] border-black"></div>

                <!-- Selesai -->
                <div class="flex flex-col items-center">
                    <img src="/images/status-selesai.png" alt="Bakso Campur" class="w-[25px] h-[25px] md:w-[45px] md:h-[45px] object-cover">
                    <span class="text-[12px] font-normal mt-2">Selesai</span>
                </div>

            </div>

            <hr class="my-4 border border-[#000000]">

            <div class="flex items-center justify-between mt-4">
                <h2 class="font-medium text-[14px] md:text-[16px]">Item Detail</h2>
            </div>

        <div class="space-y-0">
            <!-- Pesanan 1 -->
            <div class="flex items-center justify-between w-full py-2">
                <div class="flex items-center w-full gap-4">
                    <!-- Gambar Pesanan -->
                    <img src="/images/bakso campur.jpg" alt="Bakso Campur" class="w-[99px] h-[95px] md:w-[99px] md:h-[95px] object-cover rounded-2xl">
                    <!-- Detail Pesanan -->
                    <div class="flex flex-col w-full">
                        <div class="flex items-start justify-between w-full">
                            <div class="flex flex-col">
                                <span class="text-[14px] md:text-[16px] font-normal">Bakso Campur</span>
                                <span class="text-[14px] md:text-[16px] font-normal"></span>
                            </div>
                        </div>
                        <div class="flex justify-between w-full pt-5">
                            <span class="text-[14px] md:text-[16px] font-normal">1x</span>
                            <span class="ml-auto text-[14px] md:text-[16px] font-normal">Rp15.000</span>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Pesanan  2-->
            <div class="flex items-center justify-between w-full py-2">
                <div class="flex items-center w-full gap-4">
                    <!-- Gambar Pesanan -->
                    <img src="/images/mie ayam.jpg" alt="Bakso Campur" class="w-[99px] h-[95px] md:w-[99px] md:h-[95px] object-cover rounded-2xl">
                    <!-- Detail Pesanan -->
                    <div class="flex flex-col w-full">
                        <div class="flex items-start justify-between w-full">
                            <div class="flex flex-col">
                                <span class="text-[14px] md:text-[18px]">Mie Ayam</span>
                                <span class="text-[14px] md:text-[16px] font-normal">Catatan: Tidak pakai sayur</span>
                            </div>
                        </div>
                        <div class="flex justify-between w-full pt-5">
                            <span class="text-[14px] md:text-[18px]">1x</span>
                            <span class="ml-auto text-[14px] md:text-[18px]">Rp15.000</span>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Pesanan 3 -->
            <div class="flex items-center justify-between w-full py-2">
                <div class="flex items-center w-full gap-4">
                    <!-- Gambar Pesanan -->
                    <img src="/images/es teh.jpg" alt="Bakso Campur" class="w-[99px] h-[95px] md:w-[99px] md:h-[95px] object-cover rounded-2xl">
                    <!-- Detail Pesanan -->
                    <div class="flex flex-col w-full">
                        <div class="flex items-start justify-between w-full">
                            <div class="flex flex-col">
                                <span class="text-[14px] md:text-[18px]">Es Teh</span>
                                <span class="text-[14px] md:text-[16px] font-normal"></span>
                            </div>
                        </div>
                        <div class="flex justify-between w-full pt-5">
                            <span class="text-[14px] md:text-[18px]">1x</span>
                            <span class="ml-auto text-[14px] md:text-[18px]">Rp6.000</span>
                        </div>
                    </div>
                </div>
            </div>

        </div>

        <!-- Total, Status Pembayaran, Button Splitbill -->
        <div class="mt-3">
            <hr class="border-black border-1">
                <div class="flex items-center justify-between mt-3 mb-3">
                    <p class="text-[14px] md:text-[16px] font-medium">Total</p>
                    <span class="text-[14px] md:text-[16px] font-semibold">Rp 36.000</span>
                </div>
            <hr class="border-black border-1">
            <div class="mt-2 mb-2">
                <div class="bg-[#B8D576] text-[14px] md:text-[16px] inline-block font-medium px-5 py-3 text-center rounded-full">
                    Sudah Bayar
                </div>
            </div>
            <hr class="border-black border-1">
            <div class="flex items-center justify-center gap-5 pt-5 pb-5">
                <a href="/pelanggan/splitbill-scan" class="bg-[#EFB036] hover:bg-[#F2E5BF] w-full text-[14px] md:text-[16px] text-center font-medium md:px-10 py-3 rounded-full flex items-center justify-center gap-2">
                    <span>Splitbill</span>
                </a>
                <a href="" class="bg-[#EFB036] hover:bg-[#F2E5BF] w-full text-[14px] md:text-[16px] text-center font-medium md:px-10 py-3 rounded-full flex items-center justify-center gap-2">
                    <span>Download Bill</span>
                </a>
            </div>

        </div>

        </div>



    </div>

    @endsection

</body>
</html>
