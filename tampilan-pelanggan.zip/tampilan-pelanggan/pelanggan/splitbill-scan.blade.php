<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pelanggan - Splitbill Scan</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/heroicons@2.0.16/24/solid/index.js"></script>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Poppins', sans-serif;
        }
    </style>
</head>
<body class="bg-[#FFFFFF]  relative">

     <!-- Overlay Blur -->
   <div id="overlay" class="fixed inset-0 z-40 hidden backdrop-blur-md bg-black/40" onclick="toggleSidebar()"></div>

   @extends('layout.master-pelanggan2')

   @section('content')


    <!-- Container -->
<div class="relative p-4 md:p-6 content">

    <!-- Isi Konten -->
    <div class="flex flex-col flex-1 p-10 pt-5">
        <!-- Gambar -->
        <div class="flex flex-col items-center justify-center gap-4 mt-10 mb-10">
            <h2 class="text-[16px] md:text-[18px] font-medium">Split Bill</h2>
            <span class="text-[14px] md:text-[16px] text-center pb-5 font-normal">Scan bon tagihan dan tentukan jumlah yang harus dibayarkan per orang!</span>
            <img src="/images/scann.png" alt="Barcode" class="w-[207px] h-[207px] md:w-[207px] md:h-[207px] object-cover">
        </div>

    </div>

    <!-- Tombol Coba Sekarang -->
    <div class="fixed bottom-0 left-0 w-full p-4 md:p-6">
        <a href="/pelanggan/splitbill-konfirmasiitem"
            class="bg-[#EFB036] hover:bg-[#F2E5BF] w-full text-black px-4 py-3 rounded-full
                text-center flex items-center justify-center font-medium text-[14px] md:text-[16px]">
            Coba Sekarang
        </a>
    </div>


</div>


@endsection

</body>
</html>
