<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pelanggan (Konfirmasi Item)</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/heroicons@2.0.16/24/solid/index.js"></script>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Poppins', sans-serif;
        }
    </style>
</head>
<body class="bg-[#FFFFFF]  relative">
   <!-- Overlay Blur -->
   <div id="overlay" class="fixed inset-0 z-40 hidden backdrop-blur-md bg-black/40" onclick="toggleSidebar()"></div>

   @extends('layout.master-pelanggan2')

   @section('content')


    <!-- Container -->
<div class="relative p-4 content md:p-6">

    <!-- Isi Konten -->
    <div class="flex flex-col flex-1 pt-5">
            <h2 class="text-center text-[16px] md:text-[18px] font-medium">Split Bill</h2>
            <hr class="my-2 border-black">

            <!-- Subjudul -->
            <div>
                <p class="text-[14px] md:text-[16px] font-medium">Item yang terbaca</p>
                <p class="text-[12px] md:text-[14px] font-normal">Pastikan semua item sudah benar</p>
            </div>
            <div class="my-0">
            <hr class="my-5 border-black">

            <!-- Container Bill -->
            <div class="bg-[#FFF6DA] p-4 rounded-lg border-[0.3px] border-black">
                <!-- Tanggal dan Kode Transaksi -->
                <div class="flex items-center justify-between">
                    <span class="text-[12px] md:text-[14px] font-normal">02 Februari 2025 08:47</span>
                    <span class="bg-gray-200 text-[12px] md:text-[14px] font-normal px-3 py-1 rounded-full">02022501</span>
                </div>

                <hr class="my-2 border-black">


                <!-- List Item -->
                <div class="space-y-2">
                    <div class="flex justify-between">
                        <div>
                            <p class="text-[12px] md:text-[14px] font-medium">Bakso Campur</p>
                            <p class="text-[12px] md:text-[14px] font-light">1x</p>
                        </div>
                        <span class="text-[12px] md:text-[14px] font-medium">Rp 15.000</span>
                    </div>

                    <div class="flex justify-between">
                        <div>
                            <p class=" text-[12px] md:text-[14px] font-medium">Mie Ayam</p>
                            <p class="text-[12px] md:text-[14px] font-light">1x</p>
                        </div>
                        <span class="text-[12px] md:text-[14px] font-medium">Rp 15.000</span>
                    </div>

                    <div class="flex justify-between">
                        <div>
                            <p class="text-[12px] md:text-[14px] font-medium">Es Teh</p>
                            <p class="text-[12px] md:text-[14px] font-light">2x</p>
                        </div>
                        <span class="text-[12px] md:text-[14px] font-medium">Rp 6.000</span>
                    </div>
                </div>

                <hr class="my-2 border-black">

                <!-- Total -->
                <div class="flex justify-between font-semibold">
                    <p class="text-[12px] md:text-[14px] font-medium">Total</p>
                    <p class="text-[12px] md:text-[14px] font-medium">Rp 36.000</p>
                </div>
            </div>

            <!-- Button Konfirmasi -->
            <div class="fixed bottom-0 left-0 w-full p-4 md:p-6">
                <button id="openPopup" class="bg-[#EFB036] hover:bg-[#F2E5BF] p-4 w-full text-black px-4 py-3 rounded-full
                        text-center flex items-center justify-center font-medium text-[14px] md:text-[16px]">
                        Konfirmasi
                </button>
            </div>

            <!-- Popup Tambah Nama -->
            <div id="popup" class="fixed inset-0 items-center justify-center hidden bg-black bg-opacity-50 backdrop-blur-sm">
                <div class="bg-white w-[366px] h-[434px] p-6 rounded-lg shadow-lg flex flex-col items-center text-center relative">
                    <h2 class="text-lg font-semibold">Input nama anda</h2>
                    <img src="/images/boy.jpg" class="w-20 h-20 my-4 rounded-full">
                    <div class="relative w-full my-4">
                        <input type="text"
                            placeholder="Nama Anda"
                            class="w-full py-2 text-center text-gray-700 placeholder-black bg-transparent border-none outline-none">
                        <hr class="absolute bottom-0 left-0 w-full border border-black">
                    </div>

                    <div class="flex-grow"></div>

                    <!-- Tombol tutup -->
                    <button id="KonfirPopup" class="bg-[#EFB036] text-white w-full px-4 py-2 rounded-full">
                        Konfirmasi
                    </button>
                </div>
            </div>
</div>

@endsection



<script>
        // Memampilkan Pop Up Memasukkan Nama Pengguna Splitbill Siapa saja
       document.addEventListener("DOMContentLoaded", function () {

        const openPopup = document.getElementById("openPopup");
        const KonfirPopup = document.getElementById("KonfirPopup");
        const popup = document.getElementById("popup");

        if (openPopup && KonfirPopup && popup) {

            openPopup.addEventListener("click", () => {
                popup.classList.remove("hidden");
                popup.classList.add("flex");
            });

            KonfirPopup.addEventListener("click", () => {
                popup.classList.add("hidden");
                popup.classList.add("flex");
                window.location.href = "/pelanggan/splitbill-bagibill";
            });

            popup.addEventListener("click", (event) => {
                if (event.target === popup) {
                    popup.classList.add("hidden");
                    popup.classList.add("flex");
                }
            });
        }
    });
</script>


</body>
</html>
