<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pelanggan (Pembayaran Qris 1)</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/heroicons@2.0.16/24/solid/index.js"></script>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Poppins', sans-serif;
        }
    </style>
</head>
<body class="bg-[#FFFFFF] relative">
   <!-- Overlay Blur -->
   <div id="overlay" class="fixed inset-0 z-40 hidden backdrop-blur-md bg-black/40" onclick="toggleSidebar()"></div>

   @extends('layout.master-pelanggan2')

   @section('content')

    <!-- Container -->
<div class="relative p-4 content md:p-6">

    <!-- Isi Konten -->
    <div class="flex flex-col flex-1">

        <!-- Info Tanggal Pembayaran -->
        <div class="mt-0">
            <h2 class="text-[16px] md:text-[18px] font-medium">Menunggu Pembayaran</h2>
            <p class="text-[14px] md:text-[14px] pb-5 font-normal">Bayar Sebelum: 08:53, 02 Feb 2025</p>
        </div>

        <hr class="border-black border-1">

        <!-- Gambar Barcode -->
        <div class="flex flex-col items-center justify-center gap-4 mt-10 mb-10">
            <img src="/images/barcode.png" alt="Barcode" class="w-[170px] h-[170px] md:w-[170px] md:h-[170px] object-cover">

            <h2 class="text-lg font-semibold">Total: Rp 36.000</h2>

            <a href="" class="bg-[#FADA7A] hover:bg-[#F2E5BF] text-black text-sm px-4 py-2 rounded-full flex items-center gap-2">
                <img src="/images/simpan-qr.png" alt="gambar" class="w-[18px] h-[18px] md:w-[20px] md:h-[20px]">
                <span class="text-[14px] md:text-[16px] font-medium">Simpan QR Code</span>
            </a>

        </div>

        <hr class="border-black border-1">

        <!-- Unggah Bukti Pembayaran -->
        <div class="mt-4">
            <div class="flex items-center justify-between pb-3">
                <h2 class="text-[14px] md:text-[16px] font-medium">Unggah Bukti Pembayaran</h2>
            </div>

            <!-- Input File -->
            <label for="buktiPembayaran"
                class="flex items-center w-full p-3 border border-[#000000] rounded-full bg-[#FFFFFF] text-[14px] md:text-[16px] font-light cursor-pointer pl-6">
                Pilih file anda
            </label>
            <input type="file" id="buktiPembayaran" accept="image/*" class="hidden">
        </div>



    </div>

    <!-- Tombol Cek Status Pembayaran -->
    <div class="relative bottom-0 left-0 w-full mt-[200px]">
        <a href="/pelanggan/pesanan-livetracking"
           class="bg-[#FADA7A] hover:bg-[#F2E5BF] p-4 w-full text-black font-sm px-4 py-3 rounded-full
                  text-center flex items-center justify-center font-medium text-[14px] md:text-[16px]">
            Cek Status Pembayaran
        </a>
    </div>

</div>

@endsection

</body>
</html>
