<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pelanggan - (Riwayat Pesanan)</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/heroicons@2.0.16/24/solid/index.js"></script>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Poppins', sans-serif;
        }
    </style>
</head>
<body class="bg-[#FFFFFF]  relative">

     <!-- Overlay Blur -->
   <div id="overlay" class="fixed inset-0 z-40 hidden backdrop-blur-md bg-black/40" onclick="toggleSidebar()"></div>

   @extends('layout.master-pelanggan2')

   @section('content')


    <!-- Container -->
<div class="relative p-4 content md:p-6">

    <!-- Isi Konten -->
    <div class="flex flex-col flex-1 pt-4">

        <h2 class="text-[16px] md:text-[18px] text-center font-medium">Riwayat Pesanan</h2>

         <!-- Menu Makanan -->
         <div class="grid grid-cols-1 gap-4 p-2 md:[p-4] md:grid-cols-1">

            <hr class="border border-black">

            <!-- Menu Pesanan 1 -->
            <div class="bg-[#FFFFFF] rounded-2xl shadow-md flex items-center border border-1 overflow-hidden h-[100px] w-full md:h-[129px] md:w-full">
                <!-- Gambar -->
                <div class="flex-shrink-0 h-full">
                    <img src="/images/bakso campur.jpg" alt="Bakso Campur" class="w-[100px] md:w-[140px] h-full rounded-2xl object-cover">
                </div>

                <!-- Konten -->
                <div class="flex flex-col flex-1 h-full p-2 md:p-4">
                    <!-- Tanggal dan No Pesanan -->
                    <div class="flex items-center justify-between mb-2">
                        <p class="text-black font-semibold text-[12px] md:text-[14px]">02 Februari 2025 08:47</p>
                        <div class="w-[75px] h-[25px] md:w-[115px] md:h-[30px] rounded-full text-[12px] md:text-[14px] text-black bg-[#FFF6DA] border border-[#efb1362e] font-normal inline-flex items-center justify-center">
                            02022501
                        </div>
                    </div>

                    <!-- Deskripsi -->
                    <p class="text-[12px] md:text-[14px] font-light leading-tight mb-3 md:mb-4">
                        1 Bakso Campur, 1 Mie Ayam, 2 Es Teh
                    </p>

                    <!-- Harga dan Tombol -->
                    <div class="flex items-center justify-between">
                        <p class="text-black font-semibold text-[12px] md:text-[14px]">Rp 36.000</p>
                        <a href="/pelanggan/pesanan-livetracking" class="w-[82px] h-[25px] md:w-[115px] md:h-[30px] rounded-full text-[14px] md:text-[16px] bg-[#FADA7A] hover:bg-[#FFF6DA] active:bg-[#FFF6DA] font-semibold inline-flex items-center justify-center">
                            Diproses
                        </a>
                    </div>
                </div>


            </div>
         </div>

    </div>


@endsection

</body>
</html>
